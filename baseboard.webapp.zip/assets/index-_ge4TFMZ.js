var oe=Object.defineProperty;var re=(s,e,t)=>e in s?oe(s,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):s[e]=t;var f=(s,e,t)=>re(s,typeof e!="symbol"?e+"":e,t);(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const n of document.querySelectorAll('link[rel="modulepreload"]'))a(n);new MutationObserver(n=>{for(const i of n)if(i.type==="childList")for(const o of i.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&a(o)}).observe(document,{childList:!0,subtree:!0});function t(n){const i={};return n.integrity&&(i.integrity=n.integrity),n.referrerPolicy&&(i.referrerPolicy=n.referrerPolicy),n.crossOrigin==="use-credentials"?i.credentials="include":n.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function a(n){if(n.ep)return;n.ep=!0;const i=t(n);fetch(n.href,i)}})();let B=null;function le(s){B=s,typeof window<"u"&&te()}function ce(){return typeof window<"u"&&typeof window.BoardSDK<"u"}function w(){if(!window.BoardSDK)throw new Error("BoardSDK bridge not available. Are you running inside a Board WebView?");return window.BoardSDK}function te(){window.__board||(window.__board={_pending:new Map,resolve(s,e){const t=this._pending.get(s);t&&(this._pending.delete(s),t.resolve(JSON.parse(e)))},reject(s,e){const t=this._pending.get(s);t&&(this._pending.delete(s),t.reject(new Error(e)))},onPauseResult(s){B==null||B(s)}})}function M(s,...e){return te(),new Promise((t,a)=>{const n=w(),i=n[s];if(typeof i!="function"){a(new Error(`BoardSDK.${s} is not a function`));return}const r=i.apply(n,e);window.__board._pending.set(r,{resolve:t,reject:a})})}var Y;(function(s){s[s.Finger=0]="Finger",s[s.Glyph=1]="Glyph",s[s.Blob=2]="Blob"})(Y||(Y={}));var H;(function(s){s[s.None=0]="None",s[s.Began=1]="Began",s[s.Moved=2]="Moved",s[s.Ended=3]="Ended",s[s.Canceled=4]="Canceled",s[s.Stationary=5]="Stationary"})(H||(H={}));var L;(function(s){s.Profile="profile",s.Guest="guest",s.AI="ai"})(L||(L={}));const _=new Map;let U=[],F=!1;function de(s){return{contactId:s.id,x:s.x,y:s.y,orientation:s.o,type:s.t,phase:s.p,glyphId:s.g,isTouched:s.touched===1}}function me(s){const e=new DataView(s),t=e.getInt32(8,!0),a=[];for(let n=0;n<t;n++){const i=12+n*36;a.push({contactId:e.getInt32(i,!0),x:e.getFloat32(i+4,!0),y:e.getFloat32(i+8,!0),orientation:e.getFloat32(i+12,!0),type:e.getInt32(i+16,!0),phase:e.getInt32(i+20,!0),glyphId:e.getInt32(i+24,!0),isTouched:e.getInt32(i+28,!0)===1})}return a}function ue(s){let e;if(s.data instanceof ArrayBuffer)e=me(s.data);else if(typeof s.data=="string")e=(JSON.parse(s.data).c??[]).map(de);else return;const t=new Set;for(const n of e)n.phase===H.Ended||n.phase===H.Canceled?_.delete(n.contactId):(_.set(n.contactId,n),t.add(n.contactId));for(const[n,i]of _)t.has(n)||(i.phase=H.Stationary);const a=Array.from(_.values());for(const n of U)n(a)}const he={subscribe(s){U.push(s),!F&&window.boardTouch&&(window.boardTouch.onmessage=ue,window.boardTouch.postMessage("subscribe"),F=!0)},unsubscribe(s){U=U.filter(e=>e!==s),U.length===0&&F&&window.boardTouch&&(window.boardTouch.postMessage("unsubscribe"),F=!1)},getContacts(){return Array.from(_.values())},getContactsByType(s){return Array.from(_.values()).filter(e=>e.type===s)},get isSubscribed(){return F}};function pe(s){switch(s){case"guest":return L.Guest;case"ai":return L.AI;default:return L.Profile}}function K(s){const e={playerId:s.playerId,sessionId:s.sessionId,name:s.name,type:pe(s.type),avatarId:s.avatarId};return typeof s.aiTypeIndex=="number"&&s.aiTypeIndex>=0&&(e.aiTypeIndex=s.aiTypeIndex),e}const ve={getPlayers(){const s=w().getPlayers();return JSON.parse(s).map(K)},getPlayerCount(){return w().getPlayerCount()},addGuest(s){w().addGuest(s)},removePlayer(s){w().removePlayer(s)},isReady(){return w().isReady()},areServicesReady(){return w().areServicesReady()},resetPlayers(){return w().resetPlayers()},getActiveProfile(){const s=w().getActiveProfile();return s==="null"?null:K(JSON.parse(s))},setAIPlayerTypes(s){w().setAIPlayerTypes(JSON.stringify(s))},async presentAddPlayer(s){return M("presentAddPlayerSelector",s??[])},async presentReplacePlayer(s,e){return M("presentReplacePlayerSelector",s,e??[])},showProfileSwitcher(){w().showProfileSwitcher()},hideProfileSwitcher(){w().hideProfileSwitcher()}};function G(s,e=""){return typeof s=="string"?s:e}function C(s,e=0){return typeof s=="number"?s:e}function ye(s,e=!1){return typeof s=="boolean"?s:e}function X(s){return typeof s=="string"?s:null}function be(s){switch(s){case"guest":return L.Guest;case"ai":return L.AI;default:return L.Profile}}function fe(s){const e={playerId:G(s.playerId),name:G(s.name),avatarId:C(s.avatarId),type:be(s.type)};return typeof s.aiTypeIndex=="number"&&s.aiTypeIndex>=0&&(e.aiTypeIndex=s.aiTypeIndex),e}function ge(s){return Array.isArray(s)?s.map(fe):[]}function Z(s){return{id:G(s.id),description:G(s.description),createdAt:C(s.createdAt),updatedAt:C(s.updatedAt),playedTime:C(s.playedTime),fileSize:C(s.fileSize),gameVersion:G(s.gameVersion),playerCount:C(s.playerCount),hasCoverImage:ye(s.hasCoverImage),payloadChecksum:X(s.payloadChecksum),coverImageChecksum:X(s.coverImageChecksum),players:ge(s.players)}}function we(s){return{totalStorage:C(s.totalStorage),usedStorage:C(s.usedStorage),remainingStorage:C(s.remainingStorage),usagePercentage:C(s.usagePercentage)}}const Se={async create(s,e,t,a){const n=Q(e),i=await M("createSave",s,n,t,a);return Z(i)},async load(s){const e=await M("loadSave",s);return De(e.data)},async list(){const s=await M("listSaves");return Array.isArray(s)?s.map(Z):[]},async update(s,e,t,a,n){const i=Q(t);await M("updateSave",s,e,i,a,n)},async removePlayersFromSave(s){await M("removePlayersFromSave",s)},async removeActiveProfileFromSave(s){await M("removeActiveProfileFromSave",s)},async loadCoverImage(s){return(await M("loadCoverImage",s)).dataUri},getMaxDataSize(){return w().getMaxSaveDataSize()},getMaxAppStorageSize(){return w().getMaxAppStorageSize()},getMaxDescriptionLength(){return w().getMaxSaveDescriptionLength()},getAppStorageInfo(){const s=w().getAppStorageInfo(),e=JSON.parse(s);return we(e)},getUniquePlayers(s){const e=new Set;return s.flatMap(t=>t.players).filter(t=>t.type===L.Profile).filter(t=>e.has(t.playerId)?!1:(e.add(t.playerId),!0))}};function Q(s){let e="";for(let t=0;t<s.length;t++)e+=String.fromCharCode(s[t]);return btoa(e)}function De(s){const e=atob(s),t=new Uint8Array(e.length);for(let a=0;a<e.length;a++)t[a]=e.charCodeAt(a);return t}const $e=0,W=new Map,j={loadPNG(s){const e=W.get(s);if(e)return e;const t=M("loadAvatarPNG",s).then(a=>a.dataUri).catch(a=>{throw W.delete(s),a instanceof Error?a:new Error(String(a))});return W.set(s,t),t},getDefault(){return j.loadPNG($e)},forPlayer(s){return j.loadPNG(Number(s.avatarId))},clearCache(){W.clear()}};function Te(s){return Array.isArray(s)?s.map(e=>({id:typeof e.id=="string"?e.id:"",value:typeof e.value=="number"?e.value:0})):[]}const ke={RESUME:"resume",EXIT_GAME_UNSAVED:"quit",EXIT_GAME_SAVED:"save_and_quit",CUSTOM_ACTION:"custom_button"};function ae(s){const e=typeof s.action=="string"?s.action:"",t={action:ke[e]??e};return typeof s.customButtonId=="string"&&(t.customButtonId=s.customButtonId),Array.isArray(s.audioTracks)&&(t.audioTracks=Te(s.audioTracks)),t}const J=new Set;function Ee(s){const e=JSON.parse(s),t=ae(e);J.forEach(a=>a(t))}le(Ee);const Ae={setContext(s){w().setPauseContext(JSON.stringify(s))},updateContext(s){w().updatePauseContext(JSON.stringify(s))},clearContext(){w().clearPauseContext()},onResult(s){return J.add(s),()=>{J.delete(s)}},pollResult(){const s=w().getPauseResult();return!s||s==="null"?null:ae(JSON.parse(s))}},Ie={quit(){w().quit()},showProfileSwitcher(){w().showProfileSwitcher()},hideProfileSwitcher(){w().hideProfileSwitcher()}},Me="1.0.0-beta.6",D={input:he,session:ve,save:Se,avatar:j,pause:Ae,application:Ie,get isOnDevice(){return ce()},get sdkVersion(){return Me}},ee="board_family_calendar_state_v1";class x{static formatDate(e=0){const t=new Date;t.setDate(t.getDate()+e);const a=t.getFullYear(),n=String(t.getMonth()+1).padStart(2,"0"),i=String(t.getDate()).padStart(2,"0");return`${a}-${n}-${i}`}static getDefaultState(){const e=this.formatDate(0),t=this.formatDate(1),a=this.formatDate(2),n=this.formatDate(3),i=this.formatDate(4),o=this.formatDate(5),r=this.formatDate(6),l=[{id:"member_1",name:"Alex (Dad)",color:"#3b82f6"},{id:"member_2",name:"Sarah (Mom)",color:"#ec4899"},{id:"member_3",name:"Leo (Son)",color:"#10b981"},{id:"member_4",name:"Mia (Daughter)",color:"#f59e0b"}],d=[{id:"evt_1",title:"Team Standup & Planning",startDate:e,startTime:"09:00",endDate:e,endTime:"10:00",allDay:!1,memberId:"member_1",category:"work",location:"Office / Remote"},{id:"evt_2",title:"Pediatrician Checkup",startDate:e,startTime:"11:30",endDate:e,endTime:"12:30",allDay:!1,memberId:"member_4",category:"appointment",location:"Pinecrest Pediatrics"},{id:"evt_3",title:"Soccer Practice",startDate:e,startTime:"16:30",endDate:e,endTime:"18:00",allDay:!1,memberId:"member_3",category:"activity",location:"West Community Field"},{id:"evt_4",title:"Family Pizza & Movie Night",startDate:e,startTime:"19:00",endDate:e,endTime:"21:30",allDay:!1,memberId:"all",category:"family"},{id:"evt_5",title:"Piano Lesson",startDate:t,startTime:"15:30",endDate:t,endTime:"16:30",allDay:!1,memberId:"member_4",category:"activity",location:"Harmony Studio"},{id:"evt_6",title:"Dentist Appointment",startDate:t,startTime:"10:00",endDate:t,endTime:"11:00",allDay:!1,memberId:"member_2",category:"appointment"},{id:"evt_7",title:"Leo's Science Fair Project Due",startDate:a,endDate:a,allDay:!0,memberId:"member_3",category:"school"},{id:"evt_8",title:"Grocery Shopping Run",startDate:n,startTime:"14:00",endDate:n,endTime:"15:30",allDay:!1,memberId:"member_1",category:"family"},{id:"evt_9",title:"Mia's Gymnastics Meet",startDate:i,startTime:"09:00",endDate:i,endTime:"12:00",allDay:!1,memberId:"member_4",category:"activity"},{id:"evt_10",title:"Weekend Hiking Trip",startDate:o,startTime:"08:30",endDate:o,endTime:"14:00",allDay:!1,memberId:"all",category:"family",location:"Redwood Trail Park"}],c=[{id:"ch_1",title:"Empty the Dishwasher",memberId:"member_3",frequency:"daily",completedDates:[e],points:5},{id:"ch_2",title:"Walk the Dog & Feed Pets",memberId:"member_4",frequency:"daily",completedDates:[],points:5},{id:"ch_3",title:"Tidy Bedroom & Make Bed",memberId:"member_3",frequency:"daily",completedDates:[e],points:5},{id:"ch_4",title:"Water Houseplants & Garden",memberId:"member_2",frequency:"weekly",completedDates:[],points:10},{id:"ch_5",title:"Take Out Recycling & Trash",memberId:"member_1",frequency:"weekly",completedDates:[],points:10}],m={[e]:{breakfast:"Berry Oatmeal & Smoothies",lunch:"Turkey Avocado Wraps",dinner:"Homemade Woodfired Pizza",chef:"member_1"},[t]:{breakfast:"Pancakes with Maple Syrup",lunch:"Greek Salad & Pita",dinner:"Lemon Garlic Herb Salmon & Veggies",chef:"member_2"},[a]:{breakfast:"Yogurt Parfait & Granola",lunch:"Caprese Sandwiches",dinner:"Taco Tuesday & Guacamole",chef:"member_1"},[n]:{breakfast:"Scrambled Eggs & Toast",lunch:"Leftover Tacos",dinner:"Creamy Tuscan Chicken Pasta",chef:"member_2"},[i]:{breakfast:"Chia Seed Pudding",lunch:"Bento Lunchboxes",dinner:"Thai Coconut Curry & Jasmine Rice",chef:"member_1"},[o]:{breakfast:"Waffles & Fresh Fruit",lunch:"Trail Snacks & Sandwiches",dinner:"Barbecue Burgers & Sweet Potato Fries",chef:"member_2"},[r]:{breakfast:"Cinnamon French Toast",lunch:"Tomato Basil Soup & Grilled Cheese",dinner:"Slow-Cooked Pot Roast & Mashed Potatoes",chef:"member_1"}},h=[{id:"note_1",title:"Grocery Essentials",content:`• Almond milk
• Fresh spinach
• Organic eggs
• Sourdough bread
• Honeycrisp apples`,color:"yellow",updatedAt:Date.now(),pinned:!0},{id:"note_2",title:"Leo's Science Project",content:"Need poster board, solar system foam balls, and glow acrylic paint by Thursday!",color:"green",memberId:"member_3",updatedAt:Date.now(),pinned:!0},{id:"note_3",title:"Weekend Trip Packing",content:"Don't forget: sunscreen, hiking boots, water bladders, and portable charger.",color:"pink",updatedAt:Date.now()},{id:"note_4",title:"Car Maintenance",content:"Oil change scheduled for next Tuesday at 10 AM at Bayview Auto.",color:"blue",memberId:"member_1",updatedAt:Date.now()}];return{members:l,events:d,chores:c,mealPlan:m,notes:h,selectedMemberId:null,currentTab:"week",selectedDate:e,themeMode:"auto"}}static async loadState(){if(D.isOnDevice)try{if(D.session.areServicesReady()){const e=await D.save.list();if(e.length>0){const t=await D.save.load(e[0].id);this.saveId=e[0].id;const a=new TextDecoder().decode(t);return JSON.parse(a)}}}catch(e){console.warn("Could not load from Board.save, falling back:",e)}try{const e=localStorage.getItem(ee);if(e){const t=JSON.parse(e);return t.selectedDate=this.formatDate(0),t}}catch(e){console.warn("Could not read localStorage:",e)}return this.getDefaultState()}static async saveState(e){e.lastSaved=Date.now();const t=JSON.stringify(e);try{localStorage.setItem(ee,t)}catch(a){console.warn("Failed to write to localStorage:",a)}if(D.isOnDevice)try{if(D.session.areServicesReady()){const a=new TextEncoder().encode(t),n=Date.now()-this.startTime;if(this.saveId)await D.save.update(this.saveId,"Family Board Save",a,n,"1.0.0");else{const i=await D.save.create("Family Board Save",a,n,"1.0.0");this.saveId=i.id}}}catch(a){console.warn("Board.save error:",a)}}}f(x,"saveId",null),f(x,"startTime",Date.now());class N{static isOnDevice(){return D.isOnDevice}static async loadDevicePlayers(){if(!D.isOnDevice)return[];try{if(!D.session.isReady())return[];const e=D.session.getPlayers(),t=[],a=["#4f46e5","#06b6d4","#ec4899","#10b981","#f59e0b","#8b5cf6"];for(let n=0;n<e.length;n++){const i=e[n];let o;try{o=await D.avatar.forPlayer(i)}catch{try{o=await D.avatar.getDefault()}catch{o=void 0}}t.push({id:`device_${i.playerId||i.sessionId}`,name:i.name||`Player ${n+1}`,color:a[n%a.length],avatarUrl:o,isDeviceProfile:!0,sessionId:i.sessionId})}return t}catch(e){return console.warn("Could not load device players:",e),[]}}static async presentAddPlayer(){if(!D.isOnDevice)return!1;try{return await D.session.presentAddPlayer()}catch(e){return console.warn("presentAddPlayer failed:",e),!1}}static setupPauseMenu(e){if(D.isOnDevice)try{D.pause.setContext({gameName:"Family Board",offerSaveOption:!0}),D.pause.onResult(async t=>{if(t.action==="quit")D.application.quit();else if(t.action==="save_and_quit"){try{await e()}catch(a){console.error("Error during save_and_quit:",a)}D.application.quit()}})}catch(t){console.warn("setupPauseMenu failed:",t)}}}class se{static mapWeatherCode(e){return e===0?{condition:"Clear Sky",icon:"☀️"}:e===1||e===2?{condition:"Mostly Sunny",icon:"🌤️"}:e===3?{condition:"Overcast",icon:"☁️"}:e>=45&&e<=48?{condition:"Foggy",icon:"🌫️"}:e>=51&&e<=67?{condition:"Light Rain",icon:"🌧️"}:e>=71&&e<=77?{condition:"Snow Flurries",icon:"🌨️"}:e>=80&&e<=82?{condition:"Rain Showers",icon:"🌦️"}:e>=95?{condition:"Thunderstorm",icon:"⛈️"}:{condition:"Fair",icon:"⛅"}}static async getWeather(e=37.7749,t=-122.4194){var a,n,i,o;try{const r=`https://api.open-meteo.com/v1/forecast?latitude=${e}&longitude=${t}&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min,sunrise,sunset&temperature_unit=fahrenheit&timezone=auto`,l=await fetch(r);if(l.ok){const d=await l.json(),c=d.current,m=d.daily,h=this.mapWeatherCode((c==null?void 0:c.weather_code)??1);return{temp:Math.round((c==null?void 0:c.temperature_2m)??72),unit:"F",condition:h.condition,icon:h.icon,high:Math.round(((a=m==null?void 0:m.temperature_2m_max)==null?void 0:a[0])??76),low:Math.round(((n=m==null?void 0:m.temperature_2m_min)==null?void 0:n[0])??58),city:"Home",sunrise:(i=m==null?void 0:m.sunrise)==null?void 0:i[0],sunset:(o=m==null?void 0:m.sunset)==null?void 0:o[0]}}}catch{}return this.defaultWeather}}f(se,"defaultWeather",{temp:72,unit:"F",condition:"Partly Cloudy",icon:"⛅",high:76,low:58,city:"Home"});class O{static getEstimatedCoordinates(){return{lat:38,lon:-new Date().getTimezoneOffset()/60*15}}static calculateSolarTimes(e=new Date,t=38,a=O.getEstimatedCoordinates().lon){const n=Math.PI/180,i=180/Math.PI,o=new Date(e.getFullYear(),0,0),r=e.getTime()-o.getTime(),l=Math.floor(r/(1e3*60*60*24)),d=a/15,c=g=>{const b=l+((g?6:18)-d)/24,S=.9856*b-3.289;let T=S+1.916*Math.sin(S*n)+.02*Math.sin(2*S*n)+282.634;T=(T%360+360)%360;let k=i*Math.atan(.91764*Math.tan(T*n));k=(k%360+360)%360;const E=Math.floor(T/90)*90,y=Math.floor(k/90)*90;k=(k+(E-y))/15;const $=.39782*Math.sin(T*n),A=Math.cos(Math.asin($)),P=(Math.cos(90.833*n)-$*Math.sin(t*n))/(A*Math.cos(t*n)),I=Math.max(-1,Math.min(1,P));let q=g?360-i*Math.acos(I):i*Math.acos(I);q=q/15;let R=((q+k-.06571*b-6.622-d)%24+24)%24;const V=new Date(e);return V.setUTCHours(Math.floor(R),Math.floor(R%1*60),Math.floor(R*60%1*60),0),V},m=c(!0),h=c(!1),u=e.getTime(),p=u>=m.getTime()&&u<h.getTime(),v=g=>g.toLocaleTimeString([],{hour:"numeric",minute:"2-digit"});return{sunrise:m,sunset:h,isDaytime:p,sunriseStr:v(m),sunsetStr:v(h)}}static isDaytime(e,t){const a=new Date;if(e&&t){const n=new Date(e),i=new Date(t);if(!isNaN(n.getTime())&&!isNaN(i.getTime()))return a.getTime()>=n.getTime()&&a.getTime()<i.getTime()}return this.calculateSolarTimes(a).isDaytime}}class Ce{static unfold(e){const t=e.replace(/\r\n/g,`
`).replace(/\r/g,`
`).split(`
`),a=[];for(const n of t)(n.startsWith(" ")||n.startsWith("	"))&&a.length>0?a[a.length-1]+=n.slice(1):n.trim().length>0&&a.push(n.trim());return a}static unescape(e){return e.replace(/\\n/gi,`
`).replace(/\\,/g,",").replace(/\\;/g,";").replace(/\\\\/g,"\\")}static parseDate(e){const t=e.trim();if(t.length===8&&/^\d{8}$/.test(t)){const i=parseInt(t.substring(0,4),10),o=parseInt(t.substring(4,6),10)-1,r=parseInt(t.substring(6,8),10);return{date:new Date(i,o,r),allDay:!0}}const a=t.match(/^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})(Z)?/);if(a){const i=parseInt(a[1],10),o=parseInt(a[2],10)-1,r=parseInt(a[3],10),l=parseInt(a[4],10),d=parseInt(a[5],10),c=parseInt(a[6],10);return a[7]==="Z"?{date:new Date(Date.UTC(i,o,r,l,d,c)),allDay:!1}:{date:new Date(i,o,r,l,d,c),allDay:!1}}const n=new Date(t);return{date:isNaN(n.getTime())?new Date:n,allDay:!1}}static formatDateStr(e){const t=e.getFullYear(),a=String(e.getMonth()+1).padStart(2,"0"),n=String(e.getDate()).padStart(2,"0");return`${t}-${a}-${n}`}static formatTimeStr(e){const t=String(e.getHours()).padStart(2,"0"),a=String(e.getMinutes()).padStart(2,"0");return`${t}:${a}`}static parse(e,t){const a=this.unfold(e),n=[];let i=!1,o={};for(const r of a){if(r==="BEGIN:VEVENT"){i=!0,o={};continue}if(r==="END:VEVENT"){if(i=!1,o.summary&&o.start){const u=this.formatDateStr(o.start),p=o.end??o.start,v=this.formatDateStr(p),g=o.allDay??!1;n.push({id:`gcal_${t}_${o.uid||Math.random().toString(36).substring(2,9)}`,title:o.summary,description:o.description,location:o.location,startDate:u,startTime:g?void 0:this.formatTimeStr(o.start),endDate:v,endTime:g?void 0:this.formatTimeStr(p),allDay:g,memberId:t,source:"gcal",externalId:o.uid})}continue}if(!i)continue;const l=r.indexOf(":");if(l===-1)continue;const d=r.substring(0,l),c=r.substring(l+1);switch(d.split(";")[0].toUpperCase()){case"UID":o.uid=c;break;case"SUMMARY":o.summary=this.unescape(c);break;case"DESCRIPTION":o.description=this.unescape(c);break;case"LOCATION":o.location=this.unescape(c);break;case"RRULE":o.rrule=c;break;case"DTSTART":{const u=d.includes("VALUE=DATE"),p=this.parseDate(c);o.start=p.date,o.allDay=u||p.allDay;break}case"DTEND":{const u=d.includes("VALUE=DATE"),p=this.parseDate(c);o.end=p.date,(u||p.allDay)&&(o.allDay=!0);break}}}return n}static fetchJsonp(e,t=15e3){return new Promise((a,n)=>{const i=`board_gcal_cb_${Date.now()}_${Math.floor(Math.random()*1e5)}`,o=document.createElement("script"),r=e.includes("?")?"&":"?";o.src=`${e}${r}callback=${i}`,o.async=!0;let l=null;const d=()=>{l&&clearTimeout(l),o.parentNode&&o.parentNode.removeChild(o),delete window[i]};window[i]=c=>{d(),a(c)},o.onerror=()=>{d(),n(new Error("JSONP script load error"))},l=window.setTimeout(()=>{d(),n(new Error("Google Apps Script request timed out"))},t),document.head.appendChild(o)})}static mapAppsScriptEvents(e,t){return e.map(a=>({id:`gcal_${t}_${a.id||Math.random().toString(36).substring(2,9)}`,title:a.title||"(Untitled)",description:a.description||void 0,location:a.location||void 0,startDate:a.startDate,startTime:a.allDay?void 0:a.startTime||void 0,endDate:a.endDate||a.startDate,endTime:a.allDay?void 0:a.endTime||void 0,allDay:!!a.allDay,memberId:t,source:"gcal",externalId:a.id}))}static async fetchAppsScriptCalendar(e,t){if(!e||!e.startsWith("http"))throw new Error("Invalid Apps Script URL. Must start with https://script.google.com");try{const a=await this.fetchJsonp(e);if(a&&Array.isArray(a.events))return this.mapAppsScriptEvents(a.events,t);if(a&&a.error)throw new Error(a.error)}catch(a){console.warn("JSONP attempt failed, falling back to fetch:",a)}try{const a=await fetch(e,{redirect:"follow"});if(!a.ok)throw new Error(`Google Apps Script returned HTTP ${a.status}`);const n=await a.json();if(n.error)throw new Error(`Google Apps Script error: ${n.error}`);if(!Array.isArray(n.events))throw new Error("Invalid response from Google Apps Script. Expected { events: [...] }");return this.mapAppsScriptEvents(n.events,t)}catch(a){throw new Error(`Could not connect to Google Apps Script (${(a==null?void 0:a.message)||"CORS/Access Error"}). Please verify: 1) The script was authorized in Google, and 2) 'Who has access' was set to 'Anyone'.`)}}static async fetchCalendar(e,t,a){if(!e||!e.startsWith("http"))throw new Error("Invalid calendar URL. Must start with http://, https://, or webcal://");if(e.includes("script.google.com"))return await this.fetchAppsScriptCalendar(e,t);const n=e.replace(/^webcal:\/\//i,"https://"),i=n.includes("calendar.google.com")||n.includes("google.com"),o=[];if(a&&a.trim()){const r=a.trim();o.push({name:"Custom Proxy",fetch:async()=>{let l=r;r.includes("%s")?l=r.replace("%s",encodeURIComponent(n)):r.endsWith("=")?l=`${r}${encodeURIComponent(n)}`:r.endsWith("/")?l=`${r}${n}`:l=`${r}?url=${encodeURIComponent(n)}`;const d=await fetch(l);if(!d.ok)throw new Error(`Status ${d.status}`);return await d.text()}})}o.push({name:"corsproxy.io",fetch:async()=>{const r=await fetch(`https://corsproxy.io/?url=${encodeURIComponent(n)}`);if(!r.ok)throw new Error(`Status ${r.status}`);return await r.text()}}),o.push({name:"allorigins.win",fetch:async()=>{const r=await fetch(`https://api.allorigins.win/get?url=${encodeURIComponent(n)}`);if(!r.ok)throw new Error(`Status ${r.status}`);const l=await r.json();if(!l||typeof l.contents!="string")throw new Error("Invalid response format");return l.contents}}),o.push({name:"codetabs",fetch:async()=>{const r=await fetch(`https://api.codetabs.com/v1/proxy?quest=${encodeURIComponent(n)}`);if(!r.ok)throw new Error(`Status ${r.status}`);return await r.text()}}),i||o.unshift({name:"Direct",fetch:async()=>{const r=await fetch(n);if(!r.ok)throw new Error(`Status ${r.status}`);return await r.text()}});for(const r of o)try{const l=await r.fetch();if(l&&l.includes("BEGIN:VCALENDAR")){const d=this.parse(l,t);return d.length>0,d}}catch(l){l!=null&&l.message||String(l)}throw new Error("Direct iCal download was blocked by CORS. Please use the Google Apps Script integration above for 100% private, first-party sync without proxies!")}}class Pe{constructor(e,t){f(this,"container");f(this,"callbacks");f(this,"clockTimer",null);this.container=e,this.callbacks=t}render(e){var h,u;const t=new Date,a=t.toLocaleTimeString([],{hour:"numeric",minute:"2-digit"}),n=t.toLocaleDateString([],{weekday:"long",month:"short",day:"numeric"}),i=e.themeMode||"auto",o=O.isDaytime((h=e.weather)==null?void 0:h.sunrise,(u=e.weather)==null?void 0:u.sunset);let r="⚡",l="Auto";i==="auto"?(r=o?"⚡☀️":"⚡🌙",l=o?"Auto (Day)":"Auto (Night)"):i==="light"?(r="☀️",l="Light"):(r="🌙",l="Dark");const d=e.weather?`
      <div class="header-weather" title="${e.weather.condition}">
        <span class="weather-icon">${e.weather.icon}</span>
        <div class="weather-meta">
          <span class="weather-temp">${e.weather.temp}°${e.weather.unit}</span>
          <span class="weather-sub">${e.weather.condition} • H:${e.weather.high}° L:${e.weather.low}°</span>
        </div>
      </div>
    `:"",c=e.members.map(p=>{const v=e.selectedMemberId===p.id,g=p.avatarUrl?`<img src="${p.avatarUrl}" class="member-avatar-img" alt="${p.name}" />`:`<span class="member-avatar-initial" style="background-color: ${p.color}">${p.name.charAt(0).toUpperCase()}</span>`;return`
        <button class="member-chip ${v?"active":""}" data-member-id="${p.id}">
          ${g}
          <span class="member-name">${p.name.split(" ")[0]}</span>
        </button>
      `}).join(""),m=e.selectedMemberId===null;this.container.innerHTML=`
      <div class="header-top-row">
        <div class="header-brand-group">
          <div class="brand-title">Family Board</div>
          <button class="action-btn btn-settings-brand" id="btn-open-settings" title="Settings & Calendars">
            ⚙️ Settings
          </button>
          <button class="action-btn btn-theme-toggle" id="btn-toggle-theme" title="Theme: ${l}. Tap to cycle.">
            <span>${r}</span> ${l}
          </button>
          <div class="header-clock-widget">
            <span class="clock-time" id="header-clock-time">${a}</span>
            <span class="clock-date">${n}</span>
          </div>
          ${d}
        </div>

        <div class="header-members-group">
          <button class="member-chip ${m?"active":""}" data-member-id="ALL">
            <span class="member-avatar-initial all-avatar">👥</span>
            <span class="member-name">All</span>
          </button>
          ${c}
          <button class="btn-add-member" id="btn-add-member" title="Add Family Member">+</button>
        </div>

        <div class="header-actions-group">
          <button class="action-btn btn-primary" id="btn-add-event">
            <span class="btn-icon">📅</span> Add Event
          </button>
          <button class="action-btn btn-secondary" id="btn-add-chore">
            <span class="btn-icon">✨</span> Add Chore
          </button>
          <button class="action-btn btn-secondary" id="btn-add-note">
            <span class="btn-icon">📌</span> Add Note
          </button>
        </div>
      </div>

      <div class="header-tabs-row">
        <div class="tabs-left">
          <button class="nav-tab ${e.currentTab==="week"?"active":""}" data-tab="week">
            <span class="tab-icon">🗓️</span> 7-Day Schedule
          </button>
          <button class="nav-tab ${e.currentTab==="day"?"active":""}" data-tab="day">
            <span class="tab-icon">⏱️</span> Day Timeline
          </button>
          <button class="nav-tab ${e.currentTab==="chores"?"active":""}" data-tab="chores">
            <span class="tab-icon">⭐</span> Chores & Habits
          </button>
          <button class="nav-tab ${e.currentTab==="meals"?"active":""}" data-tab="meals">
            <span class="tab-icon">🍳</span> Meal Planner
          </button>
          <button class="nav-tab ${e.currentTab==="notes"?"active":""}" data-tab="notes">
            <span class="tab-icon">📌</span> Sticky Notes
          </button>
        </div>
        <div class="tabs-right">
          <button class="nav-tab tab-settings" id="btn-tab-settings">
            <span class="tab-icon">⚙️</span> Settings & Sync
          </button>
        </div>
      </div>
    `,this.bindEvents(),this.startClock()}bindEvents(){var a,n,i,o,r,l,d;this.container.querySelectorAll(".tabs-left .nav-tab").forEach(c=>{c.addEventListener("click",()=>{const m=c.dataset.tab;m&&this.callbacks.onSelectTab(m)})}),(a=this.container.querySelector("#btn-tab-settings"))==null||a.addEventListener("click",()=>{this.callbacks.onOpenSettings()}),(n=this.container.querySelector("#btn-toggle-theme"))==null||n.addEventListener("click",()=>{this.callbacks.onToggleTheme()}),this.container.querySelectorAll(".member-chip").forEach(c=>{c.addEventListener("click",()=>{const m=c.dataset.memberId;m==="ALL"?this.callbacks.onSelectMember(null):m&&this.callbacks.onSelectMember(m)})}),(i=this.container.querySelector("#btn-add-member"))==null||i.addEventListener("click",()=>{this.callbacks.onAddMember()}),(o=this.container.querySelector("#btn-add-event"))==null||o.addEventListener("click",()=>{this.callbacks.onAddEvent()}),(r=this.container.querySelector("#btn-add-chore"))==null||r.addEventListener("click",()=>{this.callbacks.onAddChore()}),(l=this.container.querySelector("#btn-add-note"))==null||l.addEventListener("click",()=>{this.callbacks.onAddNote()}),(d=this.container.querySelector("#btn-open-settings"))==null||d.addEventListener("click",()=>{this.callbacks.onOpenSettings()})}startClock(){this.clockTimer||(this.clockTimer=window.setInterval(()=>{const e=this.container.querySelector("#header-clock-time");e&&(e.textContent=new Date().toLocaleTimeString([],{hour:"numeric",minute:"2-digit"}))},1e4))}}class Le{constructor(e,t){f(this,"container");f(this,"callbacks");this.container=e,this.callbacks=t}formatDateStr(e){const t=e.getFullYear(),a=String(e.getMonth()+1).padStart(2,"0"),n=String(e.getDate()).padStart(2,"0");return`${t}-${a}-${n}`}render(e){const t=new Date;t.setHours(0,0,0,0);const a=this.formatDateStr(t),n=[];for(let l=0;l<7;l++){const d=new Date(t);d.setDate(t.getDate()+l);const c=this.formatDateStr(d);n.push({date:d,dateStr:c,isToday:c===a})}const i=new Map;e.members.forEach(l=>i.set(l.id,l));const o=e.events.filter(l=>e.selectedMemberId?l.memberId===e.selectedMemberId||l.memberId==="all":!0),r=n.map(({date:l,dateStr:d,isToday:c})=>{const m=l.toLocaleDateString([],{weekday:"short"}),h=l.toLocaleDateString([],{month:"short",day:"numeric"}),u=o.filter(b=>b.startDate<=d&&b.endDate>=d);u.sort((b,S)=>b.allDay&&!S.allDay?-1:!b.allDay&&S.allDay?1:(b.startTime||"").localeCompare(S.startTime||""));const p=e.mealPlan[d],v=p!=null&&p.dinner?`
          <div class="day-dinner-peek" title="Dinner: ${p.dinner}">
            <span class="peek-icon">🍽️</span>
            <span class="peek-text">${p.dinner}</span>
          </div>
        `:"",g=u.map(b=>{const S=b.memberId==="all"?null:i.get(b.memberId),T=S?S.color:"#6366f1",k=b.memberId==="all"?"Family":S?S.name.split(" ")[0]:"",E=b.allDay?"All Day":`${b.startTime||""}${b.endTime?" - "+b.endTime:""}`;return`
            <div class="calendar-event-card" data-event-id="${b.id}" style="--event-color: ${T}">
              <div class="event-card-header">
                <span class="event-time">${E}</span>
                <span class="event-member-tag" style="background-color: ${T}">${k}</span>
              </div>
              <div class="event-title">${b.title}</div>
              ${b.location?`<div class="event-loc">📍 ${b.location}</div>`:""}
              ${b.source==="gcal"?'<span class="event-source-badge" title="Google Calendar">GCal</span>':""}
            </div>
          `}).join("");return`
        <div class="week-column ${c?"today":""}">
          <div class="column-header" data-jump-date="${d}">
            <div class="day-name">${m}</div>
            <div class="day-date">${h} ${c?'<span class="badge-today">Today</span>':""}</div>
            ${v}
          </div>

          <div class="column-events-list">
            ${g.length>0?g:'<div class="empty-day-hint">No scheduled events</div>'}
          </div>

          <button class="btn-quick-add" data-add-date="${d}" title="Add Event for this Day">
            + Event
          </button>
        </div>
      `}).join("");this.container.innerHTML=`
      <div class="week-grid-container">
        ${r}
      </div>
    `,this.bindEvents(e)}bindEvents(e){this.container.querySelectorAll(".column-header").forEach(t=>{t.addEventListener("click",()=>{const a=t.dataset.jumpDate;a&&this.callbacks.onJumpToDay(a)})}),this.container.querySelectorAll(".btn-quick-add").forEach(t=>{t.addEventListener("click",()=>{const a=t.dataset.addDate;a&&this.callbacks.onAddEventForDate(a)})}),this.container.querySelectorAll(".calendar-event-card").forEach(t=>{t.addEventListener("click",()=>{const a=t.dataset.eventId,n=e.events.find(i=>i.id===a);n&&this.callbacks.onSelectEvent(n)})})}}class qe{constructor(e,t){f(this,"container");f(this,"callbacks");this.container=e,this.callbacks=t}render(e){const a=new Date(e.selectedDate+"T00:00:00").toLocaleDateString([],{weekday:"long",month:"long",day:"numeric",year:"numeric"}),n=e.selectedDate===new Date().toISOString().split("T")[0],i=e.selectedMemberId?e.members.filter(c=>c.id===e.selectedMemberId):e.members,o=e.events.filter(c=>c.startDate<=e.selectedDate&&c.endDate>=e.selectedDate),r=o.filter(c=>c.allDay),l=r.length>0?`
      <div class="day-allday-banner">
        <span class="allday-label">All-Day Events:</span>
        <div class="allday-events-row">
          ${r.map(c=>{const m=e.members.find(u=>u.id===c.memberId),h=(m==null?void 0:m.color)||"#6366f1";return`
                <div class="allday-badge" data-event-id="${c.id}" style="border-left: 4px solid ${h}">
                  <span class="allday-title">${c.title}</span>
                  ${m?`<span class="allday-who" style="color: ${h}">(${m.name.split(" ")[0]})</span>`:""}
                </div>
              `}).join("")}
        </div>
      </div>
    `:"",d=i.map(c=>{const m=o.filter(u=>!u.allDay&&(u.memberId===c.id||u.memberId==="all"));m.sort((u,p)=>(u.startTime||"").localeCompare(p.startTime||""));const h=m.map(u=>{const p=`${u.startTime||"Anytime"}${u.endTime?" - "+u.endTime:""}`;return`
            <div class="swimlane-event-card" data-event-id="${u.id}" style="--member-color: ${c.color}">
              <div class="swimlane-time">${p}</div>
              <div class="swimlane-title">${u.title}</div>
              ${u.location?`<div class="swimlane-loc">📍 ${u.location}</div>`:""}
              ${u.description?`<div class="swimlane-desc">${u.description}</div>`:""}
            </div>
          `}).join("");return`
        <div class="member-swimlane-col">
          <div class="swimlane-header" style="border-top: 4px solid ${c.color}">
            <div class="swimlane-member-info">
              <span class="swimlane-avatar" style="background-color: ${c.color}">
                ${c.avatarUrl?`<img src="${c.avatarUrl}" alt="${c.name}"/>`:c.name.charAt(0)}
              </span>
              <span class="swimlane-name">${c.name}</span>
            </div>
            <button class="swimlane-add-btn" data-member-id="${c.id}" title="Add Event for ${c.name}">+</button>
          </div>

          <div class="swimlane-body">
            ${h.length>0?h:'<div class="swimlane-empty">No events today</div>'}
          </div>
        </div>
      `}).join("");this.container.innerHTML=`
      <div class="day-view-container">
        <div class="day-nav-bar">
          <div class="day-nav-controls">
            <button class="day-nav-btn" id="day-prev">◀ Previous</button>
            <button class="day-nav-btn ${n?"active":""}" id="day-today">Today</button>
            <button class="day-nav-btn" id="day-next">Next ▶</button>
          </div>
          <div class="day-current-label">${a}</div>
        </div>

        ${l}

        <div class="day-swimlanes-grid">
          ${d}
        </div>
      </div>
    `,this.bindEvents(e)}bindEvents(e){var t,a,n;(t=this.container.querySelector("#day-prev"))==null||t.addEventListener("click",()=>{const i=new Date(e.selectedDate+"T00:00:00");i.setDate(i.getDate()-1),this.callbacks.onChangeDate(i.toISOString().split("T")[0])}),(a=this.container.querySelector("#day-next"))==null||a.addEventListener("click",()=>{const i=new Date(e.selectedDate+"T00:00:00");i.setDate(i.getDate()+1),this.callbacks.onChangeDate(i.toISOString().split("T")[0])}),(n=this.container.querySelector("#day-today"))==null||n.addEventListener("click",()=>{this.callbacks.onChangeDate(new Date().toISOString().split("T")[0])}),this.container.querySelectorAll(".swimlane-add-btn").forEach(i=>{i.addEventListener("click",()=>{const o=i.dataset.memberId;this.callbacks.onAddEventForTime(e.selectedDate,"09:00",o)})}),this.container.querySelectorAll(".swimlane-event-card, .allday-badge").forEach(i=>{i.addEventListener("click",()=>{const o=i.dataset.eventId,r=e.events.find(l=>l.id===o);r&&this.callbacks.onSelectEvent(r)})})}}class Ne{constructor(e,t){f(this,"container");f(this,"callbacks");this.container=e,this.callbacks=t}render(e){const t=new Date().toISOString().split("T")[0],a=new Map;e.members.forEach(d=>a.set(d.id,d));const n=e.selectedMemberId?e.members.filter(d=>d.id===e.selectedMemberId):e.members;let i=0,o=0;e.chores.forEach(d=>{i++,d.completedDates.includes(t)&&o++});const r=i>0?Math.round(o/i*100):0,l=n.map(d=>{const c=e.chores.filter(v=>v.memberId===d.id),m=c.filter(v=>v.completedDates.includes(t)).length,h=c.length,u=h>0?Math.round(m/h*100):0,p=c.map(v=>{const g=v.completedDates.includes(t);return`
            <div class="chore-item ${g?"completed":""}" data-chore-id="${v.id}">
              <div class="chore-check-hitbox" data-toggle-id="${v.id}">
                <div class="chore-checkbox ${g?"checked":""}">
                  ${g?"✓":""}
                </div>
              </div>
              <div class="chore-content" data-edit-id="${v.id}">
                <div class="chore-title">${v.title}</div>
                <div class="chore-meta">
                  <span class="chore-freq">${v.frequency}</span>
                  ${v.points?`<span class="chore-points">+${v.points} pts</span>`:""}
                  ${g?'<span class="chore-status-done">Completed Today</span>':""}
                </div>
              </div>
            </div>
          `}).join("");return`
        <div class="chores-member-card">
          <div class="chores-member-header">
            <div class="chores-member-info">
              <span class="chores-member-avatar" style="background-color: ${d.color}">
                ${d.avatarUrl?`<img src="${d.avatarUrl}" alt="${d.name}"/>`:d.name.charAt(0)}
              </span>
              <div>
                <div class="chores-member-name">${d.name}</div>
                <div class="chores-member-stats">${m}/${h} completed (${u}%)</div>
              </div>
            </div>
            <button class="chores-add-btn" data-add-member="${d.id}">+ Add</button>
          </div>

          <div class="chores-progress-bar-bg">
            <div class="chores-progress-bar-fill" style="width: ${u}%; background-color: ${d.color}"></div>
          </div>

          <div class="chores-items-list">
            ${p.length>0?p:'<div class="chores-empty">No chores assigned! 🎉</div>'}
          </div>
        </div>
      `}).join("");this.container.innerHTML=`
      <div class="chores-view-container">
        <div class="chores-summary-banner">
          <div class="summary-left">
            <div class="summary-title">Today's Family Chores & Habits</div>
            <div class="summary-sub">${o} of ${i} tasks checked off for today</div>
          </div>
          <div class="summary-progress-wrapper">
            <span class="summary-pct">${r}%</span>
            <div class="summary-progress-bar">
              <div class="summary-progress-fill" style="width: ${r}%"></div>
            </div>
          </div>
        </div>

        <div class="chores-grid">
          ${l}
        </div>
      </div>
    `,this.bindEvents(e,t)}bindEvents(e,t){this.container.querySelectorAll(".chore-check-hitbox").forEach(a=>{a.addEventListener("click",n=>{n.stopPropagation();const i=a.dataset.toggleId;i&&this.callbacks.onToggleChore(i,t)})}),this.container.querySelectorAll(".chore-content").forEach(a=>{a.addEventListener("click",()=>{const n=a.dataset.editId,i=e.chores.find(o=>o.id===n);i&&this.callbacks.onEditChore(i)})}),this.container.querySelectorAll(".chores-add-btn").forEach(a=>{a.addEventListener("click",()=>{const n=a.dataset.addMember;n&&this.callbacks.onAddChoreForMember(n)})})}}class _e{constructor(e,t){f(this,"container");f(this,"callbacks");this.container=e,this.callbacks=t}formatDateStr(e){const t=e.getFullYear(),a=String(e.getMonth()+1).padStart(2,"0"),n=String(e.getDate()).padStart(2,"0");return`${t}-${a}-${n}`}render(e){const t=new Date;t.setHours(0,0,0,0);const a=this.formatDateStr(t),n=[];for(let r=0;r<7;r++){const l=new Date(t);l.setDate(t.getDate()+r);const d=this.formatDateStr(l);n.push({date:l,dateStr:d,isToday:d===a})}const i=new Map;e.members.forEach(r=>i.set(r.id,r));const o=n.map(({date:r,dateStr:l,isToday:d})=>{const c=r.toLocaleDateString([],{weekday:"short"}),m=r.toLocaleDateString([],{month:"short",day:"numeric"}),h=e.mealPlan[l]||{breakfast:"",lunch:"",dinner:""},u=h.chef?i.get(h.chef):null;return`
        <div class="meal-day-card ${d?"today":""}" data-date="${l}">
          <div class="meal-card-header">
            <div>
              <span class="meal-day-name">${c}</span>
              <span class="meal-day-date">${m} ${d?'<span class="badge-today">Today</span>':""}</span>
            </div>
            ${u?`
              <div class="meal-chef-badge" title="Chef: ${u.name}">
                <span class="chef-icon">👨‍🍳</span>
                <span class="chef-name" style="color: ${u.color}">${u.name.split(" ")[0]}</span>
              </div>
            `:""}
          </div>

          <div class="meal-slots">
            <div class="meal-slot">
              <span class="meal-slot-label">🌅 Breakfast</span>
              <div class="meal-slot-val ${h.breakfast?"":"empty"}">${h.breakfast||"Tap to add..."}</div>
            </div>

            <div class="meal-slot">
              <span class="meal-slot-label">☀️ Lunch</span>
              <div class="meal-slot-val ${h.lunch?"":"empty"}">${h.lunch||"Tap to add..."}</div>
            </div>

            <div class="meal-slot dinner">
              <span class="meal-slot-label">🌙 Dinner</span>
              <div class="meal-slot-val ${h.dinner?"":"empty"}">${h.dinner||"Tap to add..."}</div>
            </div>
          </div>

          <button class="meal-edit-btn" data-date="${l}">✏️ Edit Meals</button>
        </div>
      `}).join("");this.container.innerHTML=`
      <div class="meals-view-container">
        <div class="meals-header-bar">
          <div class="meals-header-title">Weekly Family Meal Planner</div>
          <div class="meals-header-hint">Tap any day or slot to change meals or designate tonight's chef</div>
        </div>
        <div class="meals-grid">
          ${o}
        </div>
      </div>
    `,this.bindEvents(e)}bindEvents(e){this.container.querySelectorAll(".meal-edit-btn, .meal-day-card").forEach(t=>{t.addEventListener("click",()=>{const a=t.dataset.date;if(!a)return;const n=e.mealPlan[a]||{breakfast:"",lunch:"",dinner:""};this.callbacks.onEditDayMeals(a,n)})})}}class xe{constructor(e,t){f(this,"container");f(this,"callbacks");this.container=e,this.callbacks=t}render(e){const t=new Map;e.members.forEach(i=>t.set(i.id,i));const a=e.notes.filter(i=>e.selectedMemberId?i.memberId===e.selectedMemberId||!i.memberId:!0);a.sort((i,o)=>i.pinned&&!o.pinned?-1:!i.pinned&&o.pinned?1:o.updatedAt-i.updatedAt);const n=a.map(i=>{const o=i.memberId?t.get(i.memberId):null;return`
        <div class="sticky-note color-${i.color} ${i.pinned?"pinned":""}" data-note-id="${i.id}">
          <div class="note-pin-action" data-pin-id="${i.id}" title="${i.pinned?"Unpin note":"Pin note to top"}">
            ${i.pinned?"📌":"📍"}
          </div>
          <div class="note-body" data-edit-id="${i.id}">
            <div class="note-title">${i.title}</div>
            <div class="note-content">${i.content.replace(/\n/g,"<br/>")}</div>
          </div>
          <div class="note-footer">
            ${o?`<span class="note-author" style="color: ${o.color}">👤 ${o.name.split(" ")[0]}</span>`:'<span class="note-author">Family</span>'}
          </div>
        </div>
      `}).join("");this.container.innerHTML=`
      <div class="notes-view-container">
        <div class="notes-header-bar">
          <div class="notes-header-title">Family Pinboard & Sticky Notes</div>
          <button class="action-btn btn-primary" id="btn-add-note-inline">
            <span class="btn-icon">📌</span> + New Note
          </button>
        </div>

        <div class="notes-grid">
          ${n}
        </div>
      </div>
    `,this.bindEvents(e)}bindEvents(e){var t;(t=this.container.querySelector("#btn-add-note-inline"))==null||t.addEventListener("click",()=>{this.callbacks.onAddNote()}),this.container.querySelectorAll(".note-pin-action").forEach(a=>{a.addEventListener("click",n=>{n.stopPropagation();const i=a.dataset.pinId;i&&this.callbacks.onTogglePin(i)})}),this.container.querySelectorAll(".note-body").forEach(a=>{a.addEventListener("click",()=>{const n=a.dataset.editId,i=e.notes.find(o=>o.id===n);i&&this.callbacks.onSelectNote(i)})})}}class Oe{constructor(){f(this,"overlay");let e=document.getElementById("modal-overlay");e||(e=document.createElement("div"),e.id="modal-overlay",e.className="modal-overlay hidden",document.body.appendChild(e)),this.overlay=e}close(){this.overlay.className="modal-overlay hidden",this.overlay.innerHTML=""}showEventModal(e,t,a,n){var S,T,k;const i=!(e!=null&&e.id),o=new Date().toISOString().split("T")[0],r=(e==null?void 0:e.startDate)||t.selectedDate||o,l=(e==null?void 0:e.endDate)||r,d=(e==null?void 0:e.startTime)||"09:00",c=(e==null?void 0:e.endTime)||"10:00",m=(e==null?void 0:e.allDay)??!1,h=(e==null?void 0:e.memberId)||"all",u=(e==null?void 0:e.category)||"family",p=[`<option value="all" ${h==="all"?"selected":""}>👥 Whole Family</option>`,...t.members.map(E=>`<option value="${E.id}" ${h===E.id?"selected":""}>👤 ${E.name}</option>`)].join("");this.overlay.innerHTML=`
      <div class="modal-card">
        <div class="modal-header">
          <div class="modal-title">${i?"Add Calendar Event":"Edit Event"}</div>
          <button class="modal-close-btn" id="modal-close">✕</button>
        </div>

        <form id="event-form" class="modal-form">
          <div class="form-group">
            <label>Event Title</label>
            <input type="text" id="evt-title" required value="${(e==null?void 0:e.title)||""}" placeholder="e.g. Soccer Practice, Dentist, Family Movie Night" />
          </div>

          <div class="form-row">
            <div class="form-group">
              <label>Family Member</label>
              <select id="evt-member">${p}</select>
            </div>
            <div class="form-group">
              <label>Category</label>
              <select id="evt-category">
                <option value="family" ${u==="family"?"selected":""}>Family</option>
                <option value="school" ${u==="school"?"selected":""}>School</option>
                <option value="work" ${u==="work"?"selected":""}>Work</option>
                <option value="activity" ${u==="activity"?"selected":""}>Sports / Activity</option>
                <option value="appointment" ${u==="appointment"?"selected":""}>Appointment</option>
                <option value="other" ${u==="other"?"selected":""}>Other</option>
              </select>
            </div>
          </div>

          <div class="form-group checkbox-group">
            <label>
              <input type="checkbox" id="evt-allday" ${m?"checked":""} />
              All-day event
            </label>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label>Start Date</label>
              <input type="date" id="evt-start-date" value="${r}" required />
            </div>
            <div class="form-group time-field ${m?"disabled":""}">
              <label>Start Time</label>
              <input type="time" id="evt-start-time" value="${d}" ${m?"disabled":""} />
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label>End Date</label>
              <input type="date" id="evt-end-date" value="${l}" required />
            </div>
            <div class="form-group time-field ${m?"disabled":""}">
              <label>End Time</label>
              <input type="time" id="evt-end-time" value="${c}" ${m?"disabled":""} />
            </div>
          </div>

          <div class="form-group">
            <label>Location (Optional)</label>
            <input type="text" id="evt-location" value="${(e==null?void 0:e.location)||""}" placeholder="e.g. West Field, Room 204" />
          </div>

          <div class="form-group">
            <label>Description / Notes</label>
            <textarea id="evt-desc" rows="2" placeholder="Add details or reminders...">${(e==null?void 0:e.description)||""}</textarea>
          </div>

          <div class="modal-actions">
            ${!i&&n?'<button type="button" class="btn-danger" id="evt-delete">Delete</button>':""}
            <div class="modal-actions-right">
              <button type="button" class="btn-secondary" id="evt-cancel">Cancel</button>
              <button type="submit" class="btn-primary">Save Event</button>
            </div>
          </div>
        </form>
      </div>
    `,this.overlay.className="modal-overlay visible";const v=this.overlay.querySelector("#evt-allday"),g=this.overlay.querySelectorAll(".time-field");v.addEventListener("change",()=>{const E=v.checked;g.forEach(y=>{y.classList.toggle("disabled",E),y.querySelectorAll("input").forEach($=>$.disabled=E)})}),(S=this.overlay.querySelector("#modal-close"))==null||S.addEventListener("click",()=>this.close()),(T=this.overlay.querySelector("#evt-cancel"))==null||T.addEventListener("click",()=>this.close()),!i&&n&&(e!=null&&e.id)&&((k=this.overlay.querySelector("#evt-delete"))==null||k.addEventListener("click",()=>{n(e.id),this.close()})),this.overlay.querySelector("#event-form").addEventListener("submit",E=>{E.preventDefault();const y=this.overlay.querySelector("#evt-title").value.trim(),$=this.overlay.querySelector("#evt-member").value,A=this.overlay.querySelector("#evt-category").value,P=this.overlay.querySelector("#evt-start-date").value,I=this.overlay.querySelector("#evt-end-date").value,q=v.checked,z=q?void 0:this.overlay.querySelector("#evt-start-time").value,R=q?void 0:this.overlay.querySelector("#evt-end-time").value,V=this.overlay.querySelector("#evt-location").value.trim(),ne=this.overlay.querySelector("#evt-desc").value.trim(),ie={id:(e==null?void 0:e.id)||`evt_${Date.now()}_${Math.random().toString(36).substr(2,4)}`,title:y,startDate:P,endDate:I,startTime:z,endTime:R,allDay:q,memberId:$,category:A,location:V||void 0,description:ne||void 0,source:(e==null?void 0:e.source)||"local"};a(ie),this.close()})}showChoreModal(e,t,a,n){var m,h,u,p;const i=!(e!=null&&e.id),o=(e==null?void 0:e.memberId)||((m=t.members[0])==null?void 0:m.id)||"member_1",r=(e==null?void 0:e.frequency)||"daily",l=(e==null?void 0:e.points)??5,d=t.members.map(v=>`<option value="${v.id}" ${o===v.id?"selected":""}>👤 ${v.name}</option>`).join("");this.overlay.innerHTML=`
      <div class="modal-card">
        <div class="modal-header">
          <div class="modal-title">${i?"Add Family Chore":"Edit Chore"}</div>
          <button class="modal-close-btn" id="modal-close">✕</button>
        </div>

        <form id="chore-form" class="modal-form">
          <div class="form-group">
            <label>Chore / Responsibility</label>
            <input type="text" id="ch-title" required value="${(e==null?void 0:e.title)||""}" placeholder="e.g. Empty dishwasher, Walk the dog" />
          </div>

          <div class="form-row">
            <div class="form-group">
              <label>Assigned To</label>
              <select id="ch-member">${d}</select>
            </div>
            <div class="form-group">
              <label>Frequency</label>
              <select id="ch-freq">
                <option value="daily" ${r==="daily"?"selected":""}>Daily</option>
                <option value="weekly" ${r==="weekly"?"weekly":""}>Weekly</option>
              </select>
            </div>
          </div>

          <div class="form-group">
            <label>Points Reward</label>
            <input type="number" id="ch-points" min="1" max="50" value="${l}" />
          </div>

          <div class="modal-actions">
            ${!i&&n?'<button type="button" class="btn-danger" id="ch-delete">Delete</button>':""}
            <div class="modal-actions-right">
              <button type="button" class="btn-secondary" id="ch-cancel">Cancel</button>
              <button type="submit" class="btn-primary">Save Chore</button>
            </div>
          </div>
        </form>
      </div>
    `,this.overlay.className="modal-overlay visible",(h=this.overlay.querySelector("#modal-close"))==null||h.addEventListener("click",()=>this.close()),(u=this.overlay.querySelector("#ch-cancel"))==null||u.addEventListener("click",()=>this.close()),!i&&n&&(e!=null&&e.id)&&((p=this.overlay.querySelector("#ch-delete"))==null||p.addEventListener("click",()=>{n(e.id),this.close()})),this.overlay.querySelector("#chore-form").addEventListener("submit",v=>{v.preventDefault();const g=this.overlay.querySelector("#ch-title").value.trim(),b=this.overlay.querySelector("#ch-member").value,S=this.overlay.querySelector("#ch-freq").value,T=parseInt(this.overlay.querySelector("#ch-points").value,10)||5,k={id:(e==null?void 0:e.id)||`ch_${Date.now()}`,title:g,memberId:b,frequency:S,points:T,completedDates:(e==null?void 0:e.completedDates)||[]};a(k),this.close()})}showMealModal(e,t,a,n){var d,c;const o=new Date(e+"T00:00:00").toLocaleDateString([],{weekday:"long",month:"short",day:"numeric"}),r=['<option value="">-- Select Chef / Cook --</option>',...a.members.map(m=>`<option value="${m.id}" ${t.chef===m.id?"selected":""}>👨‍🍳 ${m.name}</option>`)].join("");this.overlay.innerHTML=`
      <div class="modal-card">
        <div class="modal-header">
          <div class="modal-title">Edit Meals for ${o}</div>
          <button class="modal-close-btn" id="modal-close">✕</button>
        </div>

        <form id="meal-form" class="modal-form">
          <div class="form-group">
            <label>🌅 Breakfast</label>
            <input type="text" id="meal-b" value="${t.breakfast||""}" placeholder="e.g. Oatmeal & berries" />
          </div>

          <div class="form-group">
            <label>☀️ Lunch</label>
            <input type="text" id="meal-l" value="${t.lunch||""}" placeholder="e.g. Turkey Avocado Wraps" />
          </div>

          <div class="form-group">
            <label>🌙 Dinner</label>
            <input type="text" id="meal-d" value="${t.dinner||""}" placeholder="e.g. Salmon & Veggies" />
          </div>

          <div class="form-group">
            <label>Tonight's Chef</label>
            <select id="meal-chef">${r}</select>
          </div>

          <div class="modal-actions">
            <div></div>
            <div class="modal-actions-right">
              <button type="button" class="btn-secondary" id="meal-cancel">Cancel</button>
              <button type="submit" class="btn-primary">Save Meals</button>
            </div>
          </div>
        </form>
      </div>
    `,this.overlay.className="modal-overlay visible",(d=this.overlay.querySelector("#modal-close"))==null||d.addEventListener("click",()=>this.close()),(c=this.overlay.querySelector("#meal-cancel"))==null||c.addEventListener("click",()=>this.close()),this.overlay.querySelector("#meal-form").addEventListener("submit",m=>{m.preventDefault();const h=this.overlay.querySelector("#meal-b").value.trim(),u=this.overlay.querySelector("#meal-l").value.trim(),p=this.overlay.querySelector("#meal-d").value.trim(),v=this.overlay.querySelector("#meal-chef").value||void 0;n(e,{breakfast:h,lunch:u,dinner:p,chef:v}),this.close()})}showNoteModal(e,t,a,n){var c,m,h;const i=!(e!=null&&e.id),o=(e==null?void 0:e.color)||"yellow",r=(e==null?void 0:e.memberId)||"",l=['<option value="">All Family</option>',...t.members.map(u=>`<option value="${u.id}" ${r===u.id?"selected":""}>👤 ${u.name}</option>`)].join("");this.overlay.innerHTML=`
      <div class="modal-card">
        <div class="modal-header">
          <div class="modal-title">${i?"New Sticky Note":"Edit Sticky Note"}</div>
          <button class="modal-close-btn" id="modal-close">✕</button>
        </div>

        <form id="note-form" class="modal-form">
          <div class="form-group">
            <label>Note Title</label>
            <input type="text" id="nt-title" required value="${(e==null?void 0:e.title)||""}" placeholder="e.g. Grocery List, Reminder" />
          </div>

          <div class="form-group">
            <label>Content</label>
            <textarea id="nt-content" rows="4" required placeholder="Write your note here...">${(e==null?void 0:e.content)||""}</textarea>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label>Sticky Color</label>
              <select id="nt-color">
                <option value="yellow" ${o==="yellow"?"selected":""}>🟡 Yellow</option>
                <option value="green" ${o==="green"?"selected":""}>🟢 Green</option>
                <option value="blue" ${o==="blue"?"selected":""}>🔵 Blue</option>
                <option value="pink" ${o==="pink"?"selected":""}>🌸 Pink</option>
                <option value="purple" ${o==="purple"?"selected":""}>🟣 Purple</option>
              </select>
            </div>
            <div class="form-group">
              <label>Member Tag</label>
              <select id="nt-member">${l}</select>
            </div>
          </div>

          <div class="form-group checkbox-group">
            <label>
              <input type="checkbox" id="nt-pinned" ${e!=null&&e.pinned?"checked":""} />
              Pin to top of board
            </label>
          </div>

          <div class="modal-actions">
            ${!i&&n?'<button type="button" class="btn-danger" id="nt-delete">Delete</button>':""}
            <div class="modal-actions-right">
              <button type="button" class="btn-secondary" id="nt-cancel">Cancel</button>
              <button type="submit" class="btn-primary">Save Note</button>
            </div>
          </div>
        </form>
      </div>
    `,this.overlay.className="modal-overlay visible",(c=this.overlay.querySelector("#modal-close"))==null||c.addEventListener("click",()=>this.close()),(m=this.overlay.querySelector("#nt-cancel"))==null||m.addEventListener("click",()=>this.close()),!i&&n&&(e!=null&&e.id)&&((h=this.overlay.querySelector("#nt-delete"))==null||h.addEventListener("click",()=>{n(e.id),this.close()})),this.overlay.querySelector("#note-form").addEventListener("submit",u=>{u.preventDefault();const p=this.overlay.querySelector("#nt-title").value.trim(),v=this.overlay.querySelector("#nt-content").value.trim(),g=this.overlay.querySelector("#nt-color").value,b=this.overlay.querySelector("#nt-member").value||void 0,S=this.overlay.querySelector("#nt-pinned").checked,T={id:(e==null?void 0:e.id)||`note_${Date.now()}`,title:p,content:v,color:g,memberId:b,pinned:S,updatedAt:Date.now()};a(T),this.close()})}showSettingsModal(e,t,a,n,i,o){var p,v,g,b,S,T,k,E;const r=O.calculateSolarTimes(),l=O.isDaytime((p=e.weather)==null?void 0:p.sunrise,(v=e.weather)==null?void 0:v.sunset),d=(g=e.weather)!=null&&g.sunrise?new Date(e.weather.sunrise).toLocaleTimeString([],{hour:"numeric",minute:"2-digit"}):r.sunriseStr,c=(b=e.weather)!=null&&b.sunset?new Date(e.weather.sunset).toLocaleTimeString([],{hour:"numeric",minute:"2-digit"}):r.sunsetStr,m=e.themeMode||"auto",h=e.members.map(y=>`
        <div class="settings-member-row" data-mid="${y.id}">
          <div class="settings-member-label">
            <span class="member-avatar-initial" style="background-color: ${y.color}">
              ${y.avatarUrl?`<img src="${y.avatarUrl}" class="member-avatar-img" alt="${y.name}"/>`:y.name.charAt(0)}
            </span>
            <span class="settings-mname">${y.name}</span>
          </div>
          <div class="settings-member-input-col">
            <input type="url" class="gcal-url-input" data-mid="${y.id}" value="${y.calendarUrl||""}" placeholder="Paste Google Apps Script Web App URL" />
            <button class="btn-sync-gcal" data-mid="${y.id}">Sync Online</button>
            <button class="btn-delete-member" data-mid="${y.id}" title="Remove ${y.name}">🗑️</button>
          </div>
        </div>
      `).join("");this.overlay.innerHTML=`
      <div class="modal-card modal-card-large">
        <div class="modal-header">
          <div class="modal-title">⚙️ Settings & Display</div>
          <button class="modal-close-btn" id="modal-close">✕</button>
        </div>

        <div class="settings-body">
          <div class="settings-section">
            <div class="settings-sec-title">🌓 Display & Theme</div>
            <p class="settings-sec-desc">
              Select your appearance preference or let the board automatically switch based on local sunrise and sunset.
            </p>
            <div class="theme-options-grid">
              <button class="theme-option-btn ${m==="auto"?"active":""}" data-theme-mode="auto">
                <span class="theme-option-icon">⚡</span>
                <div class="theme-option-text">
                  <span class="theme-option-title">Automatic</span>
                  <span class="theme-option-desc">Rise ${d} • Set ${c} (${l?"Day ☀️":"Night 🌙"})</span>
                </div>
              </button>

              <button class="theme-option-btn ${m==="light"?"active":""}" data-theme-mode="light">
                <span class="theme-option-icon">☀️</span>
                <div class="theme-option-text">
                  <span class="theme-option-title">Always Light</span>
                  <span class="theme-option-desc">Crisp daytime mode</span>
                </div>
              </button>

              <button class="theme-option-btn ${m==="dark"?"active":""}" data-theme-mode="dark">
                <span class="theme-option-icon">🌙</span>
                <div class="theme-option-text">
                  <span class="theme-option-title">Always Dark</span>
                  <span class="theme-option-desc">Cozy evening contrast</span>
                </div>
              </button>
            </div>
          </div>

          <div class="settings-section">
            <div class="settings-sec-title">Family Members & Google Calendar Sync</div>
            <p class="settings-sec-desc">
              Paste each member's Google Apps Script Web App URL to automatically sync their calendar.
            </p>

            <div class="settings-members-list">
              ${h.length>0?h:'<div class="settings-empty-members">No family members yet. Add one below!</div>'}
            </div>
            <div id="sync-status" class="sync-status-msg"></div>
          </div>

          <div class="settings-section">
            <div class="settings-sec-title">Add New Family Member</div>
            <div class="settings-add-member-form">
              <input type="text" id="new-mem-name" placeholder="Member Name (e.g. Dad, Mom, Charlie, Grandma)" />
              <input type="color" id="new-mem-color" value="#8b5cf6" title="Choose color badge" />
              <button class="action-btn btn-secondary" id="btn-create-member">+ Add Member</button>
            </div>
          </div>

          <div class="settings-section danger-zone">
            <div class="settings-sec-title">Reset Demo Data</div>
            <p class="settings-sec-desc">Restore original sample events, chores, and weekly meal plan.</p>
            <button class="btn-danger" id="btn-reset-demo">Reset to Default Data</button>
          </div>
        </div>

        <div class="modal-actions">
          <div></div>
          <button class="btn-primary" id="settings-done">Done</button>
        </div>
      </div>
    `,this.overlay.className="modal-overlay visible",(S=this.overlay.querySelector("#modal-close"))==null||S.addEventListener("click",()=>this.close()),(T=this.overlay.querySelector("#settings-done"))==null||T.addEventListener("click",()=>this.close()),this.overlay.querySelectorAll(".theme-option-btn").forEach(y=>{y.addEventListener("click",()=>{const $=y.dataset.themeMode;$&&(o($),this.showSettingsModal(e,t,a,n,i,o))})});const u=this.overlay.querySelector("#sync-status");this.overlay.querySelectorAll(".btn-sync-gcal").forEach(y=>{y.addEventListener("click",async()=>{const $=y.dataset.mid;if(!$)return;const A=this.overlay.querySelector(`.gcal-url-input[data-mid="${$}"]`),P=(A==null?void 0:A.value.trim())||"";y.disabled=!0,y.textContent="Syncing...",u.textContent="Fetching and syncing calendar directly from Google...",u.className="sync-status-msg pending";try{await t($,P),u.textContent="✓ Calendar synced successfully from Google!",u.className="sync-status-msg success"}catch(I){u.textContent=`Sync notice: ${(I==null?void 0:I.message)||"Could not fetch calendar"}`,u.className="sync-status-msg error"}finally{y.disabled=!1,y.textContent="Sync Online"}})}),this.overlay.querySelectorAll(".btn-delete-member").forEach(y=>{y.addEventListener("click",()=>{const $=y.dataset.mid;if(!$)return;const A=e.members.find(I=>I.id===$),P=A?A.name:"this member";confirm(`Remove ${P} from the family board?`)&&(n($),this.showSettingsModal(e,t,a,n,i,o))})}),(k=this.overlay.querySelector("#btn-create-member"))==null||k.addEventListener("click",()=>{const y=this.overlay.querySelector("#new-mem-name"),$=this.overlay.querySelector("#new-mem-color"),A=y.value.trim(),P=$.value;A&&(a(A,P),this.showSettingsModal(e,t,a,n,i,o))}),(E=this.overlay.querySelector("#btn-reset-demo"))==null||E.addEventListener("click",()=>{confirm("Reset all calendar events, chores, and meal plans back to defaults?")&&(i(),this.close())})}}class Re{constructor(){f(this,"state");f(this,"headerComponent");f(this,"weekView");f(this,"dayView");f(this,"choresView");f(this,"mealsView");f(this,"notesView");f(this,"modals");f(this,"headerContainer",document.getElementById("app-header"));f(this,"mainContainer",document.getElementById("main-view"))}async init(){if(this.state=await x.loadState(),N.isOnDevice()){const e=await N.loadDevicePlayers();if(e.length>0)for(const t of e){const a=this.state.members.find(n=>n.id===t.id);a?(a.avatarUrl=t.avatarUrl||a.avatarUrl,a.name=t.name):this.state.members.push(t)}N.setupPauseMenu(async()=>{await x.saveState(this.state)})}this.modals=new Oe,this.headerComponent=new Pe(this.headerContainer,{onSelectTab:e=>this.setTab(e),onSelectMember:e=>this.setMemberFilter(e),onAddMember:()=>this.handleAddMember(),onAddEvent:()=>this.handleAddEvent(),onAddChore:()=>this.handleAddChore(),onAddNote:()=>this.handleAddNote(),onOpenSettings:()=>this.handleOpenSettings(),onToggleTheme:()=>this.handleToggleTheme()}),this.weekView=new Le(this.mainContainer,{onSelectEvent:e=>this.handleEditEvent(e),onAddEventForDate:e=>this.handleAddEvent({startDate:e,endDate:e}),onJumpToDay:e=>{this.state.selectedDate=e,this.setTab("day")}}),this.dayView=new qe(this.mainContainer,{onSelectEvent:e=>this.handleEditEvent(e),onAddEventForTime:(e,t,a)=>{this.handleAddEvent({startDate:e,endDate:e,startTime:t,memberId:a||"all",allDay:!1})},onChangeDate:e=>{this.state.selectedDate=e,this.renderView()}}),this.choresView=new Ne(this.mainContainer,{onToggleChore:(e,t)=>this.handleToggleChore(e,t),onEditChore:e=>this.handleEditChore(e),onAddChoreForMember:e=>this.handleAddChore(e)}),this.mealsView=new _e(this.mainContainer,{onEditDayMeals:(e,t)=>this.handleEditMeals(e,t)}),this.notesView=new xe(this.mainContainer,{onSelectNote:e=>this.handleEditNote(e),onAddNote:()=>this.handleAddNote(),onTogglePin:e=>this.handleTogglePinNote(e)}),this.applyTheme(),this.render(),setInterval(()=>{(this.state.themeMode||"auto")==="auto"&&(this.applyTheme(),this.headerComponent.render(this.state))},60*1e3),this.updateWeather(),setInterval(()=>this.updateWeather(),1800*1e3),this.syncAllGoogleCalendars(),setInterval(()=>this.syncAllGoogleCalendars(),900*1e3)}async updateWeather(){const e=await se.getWeather();this.state.weather=e,this.applyTheme(),this.headerComponent.render(this.state)}render(){this.headerComponent.render(this.state),this.renderView()}renderView(){switch(this.state.currentTab){case"week":this.weekView.render(this.state);break;case"day":this.dayView.render(this.state);break;case"chores":this.choresView.render(this.state);break;case"meals":this.mealsView.render(this.state);break;case"notes":this.notesView.render(this.state);break}}setTab(e){this.state.currentTab=e,this.render()}setMemberFilter(e){this.state.selectedMemberId=e,this.render()}async saveAndRender(){await x.saveState(this.state),this.render()}async handleAddMember(){if(N.isOnDevice()&&await N.presentAddPlayer()){const t=await N.loadDevicePlayers();for(const a of t)this.state.members.some(n=>n.id===a.id)||this.state.members.push(a);await this.saveAndRender();return}this.handleOpenSettings()}handleAddEvent(e){this.modals.showEventModal(e||null,this.state,async t=>{this.state.events.push(t),await this.saveAndRender()})}handleEditEvent(e){this.modals.showEventModal(e,this.state,async t=>{const a=this.state.events.findIndex(n=>n.id===t.id);a!==-1?this.state.events[a]=t:this.state.events.push(t),await this.saveAndRender()},async t=>{this.state.events=this.state.events.filter(a=>a.id!==t),await this.saveAndRender()})}handleAddChore(e){this.modals.showChoreModal(e?{memberId:e}:null,this.state,async t=>{this.state.chores.push(t),await this.saveAndRender()})}handleEditChore(e){this.modals.showChoreModal(e,this.state,async t=>{const a=this.state.chores.findIndex(n=>n.id===t.id);a!==-1?this.state.chores[a]=t:this.state.chores.push(t),await this.saveAndRender()},async t=>{this.state.chores=this.state.chores.filter(a=>a.id!==t),await this.saveAndRender()})}async handleToggleChore(e,t){const a=this.state.chores.find(i=>i.id===e);if(!a)return;const n=a.completedDates.indexOf(t);n!==-1?a.completedDates.splice(n,1):a.completedDates.push(t),await this.saveAndRender()}handleEditMeals(e,t){this.modals.showMealModal(e,t,this.state,async(a,n)=>{this.state.mealPlan[a]=n,await this.saveAndRender()})}handleAddNote(){this.modals.showNoteModal(null,this.state,async e=>{this.state.notes.push(e),await this.saveAndRender()})}handleEditNote(e){this.modals.showNoteModal(e,this.state,async t=>{const a=this.state.notes.findIndex(n=>n.id===t.id);a!==-1?this.state.notes[a]=t:this.state.notes.push(t),await this.saveAndRender()},async t=>{this.state.notes=this.state.notes.filter(a=>a.id!==t),await this.saveAndRender()})}async handleTogglePinNote(e){const t=this.state.notes.find(a=>a.id===e);t&&(t.pinned=!t.pinned,t.updatedAt=Date.now(),await this.saveAndRender())}handleOpenSettings(){this.modals.showSettingsModal(this.state,async(e,t)=>{const a=this.state.members.find(n=>n.id===e);a&&(a.calendarUrl=t,t&&await this.syncMemberGoogleCalendar(a),await this.saveAndRender())},async(e,t)=>{const a={id:`custom_${Date.now()}`,name:e,color:t};this.state.members.push(a),await this.saveAndRender()},async e=>{this.state.members=this.state.members.filter(t=>t.id!==e),this.state.events=this.state.events.filter(t=>t.memberId!==e),this.state.chores=this.state.chores.filter(t=>t.memberId!==e);for(const t of this.state.notes)t.memberId===e&&delete t.memberId;for(const t in this.state.mealPlan)this.state.mealPlan[t].chef===e&&delete this.state.mealPlan[t].chef;this.state.selectedMemberId===e&&(this.state.selectedMemberId=null),await this.saveAndRender()},async()=>{this.state=x.getDefaultState(),await this.saveAndRender()},async e=>{this.state.themeMode=e,this.applyTheme(),await this.saveAndRender()})}async handleToggleTheme(){const e=this.state.themeMode||"auto";let t="auto";e==="auto"?t="light":e==="light"?t="dark":t="auto",this.state.themeMode=t,this.applyTheme(),await this.saveAndRender()}applyTheme(){var a,n;const e=this.state.themeMode||"auto";let t="dark";e==="light"?t="light":e==="dark"?t="dark":t=O.isDaytime((a=this.state.weather)==null?void 0:a.sunrise,(n=this.state.weather)==null?void 0:n.sunset)?"light":"dark",document.documentElement.setAttribute("data-theme",t)}async syncMemberGoogleCalendar(e){if(e.calendarUrl)try{const t=await Ce.fetchCalendar(e.calendarUrl,e.id,this.state.customCorsProxy);this.state.events=this.state.events.filter(a=>!(a.source==="gcal"&&a.memberId===e.id)),this.state.events.push(...t),this.state.lastSynced=Date.now()}catch(t){throw console.warn(`Failed to sync calendar for ${e.id}:`,t),t}}async syncAllGoogleCalendars(){let e=!1;for(const t of this.state.members)if(t.calendarUrl)try{await this.syncMemberGoogleCalendar(t),e=!0}catch{}e&&await this.saveAndRender()}}const Fe=new Re;Fe.init().catch(s=>{console.error("Initialization error:",s)});
